<?php require "conn.php" ?>
<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            margin: 10px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }

        .nospacing {
            margin: 0;
            padding: 0;
        }

        table {
            border-collapse: collapse;
        }
        th,
        td {
            border: 1px solid black;
            margin-left:2px;
        }
        .no-border {
            border: 0;
        }

    </style>
</head>

<body>
    <h2 class="nospacing">Laporan Pasien Per Daerah</h2>

    <?php
    $daerah = $conn->query("SELECT * FROM daerah");
    $daerah = $daerah->fetch_all(1);

    foreach ($daerah as $k => $v) {
    ?>
        <h3 class="nospacing">Kota <?php echo $v["kota"] ?></h3>
        <?php

        $rumah_sakit = $conn->query("SELECT * FROM rumah_sakit WHERE daerah_id = '" . $v["id"] . "'");
        $rumah_sakit = $rumah_sakit->fetch_all(1);

        foreach ($rumah_sakit as $kk => $vv) {
        ?>
            <h3 class="nospacing">RS <?php echo $vv["nama"] ?></h3>

            <table>
                <thead>
                    <tr>
                        <th style="width:120px">Tanggal Masuk</th>
                        <th style="width:120px">Nama</th>
                        <th style="width:120px">Alamat</th>
                        <th style="width:180px">TTL</th>
                        <th style="width:120px">No.HP</th>
                        <th style="width:120px">Jenis Kelamin</th>
                        <th style="width:120px">Status</th>
                        <th style="width:120px">Dokter</th>
                        <th style="width:120px">Pembiayaan</th>
                        <th style="width:120px">Tanggal Konsultasi Kembali</th>
                        <th style="width:120px">Pakai Baju Warna</th>
                        <th style="width:120px">Vaksin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $pasien = $conn->query("SELECT * FROM pasien WHERE rumah_sakit = '" . $vv["id"] . "'");
                    $pasien = $pasien->fetch_all(1);

                    $pasien_pria = $conn->query("SELECT * FROM pasien WHERE rumah_sakit = '" . $vv["id"] . "' AND jenis_kelamin = 'Pria'");
                    $pasien_pria = $pasien_pria->fetch_all(1);
                    
                    $pasien_nonbpjs = $conn->query("SELECT * FROM pasien WHERE rumah_sakit = '" . $vv["id"] . "' AND pembiayaan != 'BPJS'");
                    $pasien_nonbpjs = $pasien_nonbpjs->fetch_all(1);
                    
                    $total_vaksin = $conn->query("SELECT SUM(vaksin) as total FROM pasien WHERE rumah_sakit = '" . $vv["id"] . "'");
                    $total_vaksin = $total_vaksin->fetch_all(1);
                    foreach ($pasien as $kkk=>$vvv) {
                        ?>
                        <tr>
                            <td><?php echo $vvv["tanggal_masuk"] ?></td>
                            <td><?php echo $vvv["nama"] ?></td>
                            <td><?php echo $vvv["alamat"] ?></td>
                            <td><?php echo $vvv["ttl"] ?></td>
                            <td><?php echo $vvv["no_hp"] ?></td>
                            <td><?php echo $vvv["jenis_kelamin"] ?></td>
                            <td><?php echo $vvv["status"] ?></td>
                            <td><?php echo $vvv["dokter"] ?></td>
                            <td><?php echo $vvv["pembiayaan"] ?></td>
                            <td><?php echo $vvv["tanggal_konsultasi_kembali"] ?></td>
                            <td><?php echo $vvv["pakai_baju_warna"] ?></td>
                            <td><?php echo $vvv["vaksin"] ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                    <tr>
                        <td>Jumlah Pasien</td>
                        <td><?php echo count($pasien) ?> orang</td>
                        <td class="no-border" colspan="3"></td>
                        <td colspan="2">Pasien Pria</td>
                        <td><?php echo count($pasien_pria) ?> orang</td>
                        <td class="no-border"></td>
                        <td>Total Vaksin</td>
                        <td><?php echo $total_vaksin[0]["total"] ?></td>
                    </tr>
                    <tr>
                        <td>NON BPJS</td>
                        <td><?php echo count($pasien_nonbpjs) ?> orang</td>
                        <td class="no-border" colspan="3"></td>
                        <td colspan="2">Pasien Wanita</td>
                        <td><?php echo count($pasien)-count($pasien_pria) ?> orang</td>
                    </tr>
                    <tr>
                        <td>NON BPJS</td>
                        <td><?php echo count($pasien) - count($pasien_nonbpjs) ?> orang</td>
                    </tr>
                </tbody>
            </table>
    <?php
        }
        echo "<br>";
    }
    ?>
</body>

</html>