<?php
require "conn.php";

$tanggal_masuk = $_POST["tanggal_masuk"];
$nama = $_POST["nama"];
$alamat = $_POST["alamat"];
$ttl = $_POST["ttl"];
$no_hp = $_POST["no_hp"];
$jenis_kelamin = $_POST["jenis_kelamin"];
$status = $_POST["status"];
$dokter = $_POST["dokter"];
$pembiayaan = $_POST["pembiayaan"];
$tanggal_konsultasi_kembali = ($status == "OTG") ? strtotime("+20 day", strtotime($tanggal_masuk)) : strtotime("+10 day", strtotime($tanggal_masuk));
if (strtoupper($nama[0]) == "B") {
    $pakai_baju_warna = "Hijau";
} elseif (strtoupper($nama[0]) == "S") {
    $pakai_baju_warna = "Biru";
} elseif (strtoupper($nama[0]) == "P") {
    $pakai_baju_warna = "Kuning";
} elseif (strtoupper($nama[0]) == "C") {
    $pakai_baju_warna = "Abu Abu";
} else {
    $pakai_baju_warna = "";
}
$vaksin = $_POST["vaksin"];
$rumah_sakit = $_POST["rumah_sakit"];

$tanggal_konsultasi_kembali = date("Y-m-d", $tanggal_konsultasi_kembali);

$conn->query("INSERT INTO pasien (tanggal_masuk,nama,alamat,ttl,no_hp,jenis_kelamin,status,dokter,pembiayaan,tanggal_konsultasi_kembali,pakai_baju_warna,vaksin,rumah_sakit) 
VALUES 
('$tanggal_masuk','$nama','$alamat','$ttl','$no_hp','$jenis_kelamin','$status','$dokter','$pembiayaan','$tanggal_konsultasi_kembali','$pakai_baju_warna','$vaksin','$rumah_sakit')");

header("Location: /jjoki/");